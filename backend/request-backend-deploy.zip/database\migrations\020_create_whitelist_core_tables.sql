-- NO-OP migration: target tables already existed with a different schema.
SELECT 1;
